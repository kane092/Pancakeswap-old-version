import React, { useState } from 'react'
import '../../Home/components/style.css'
// import { Link } from 'react-router-dom'
import { Box, Flex, Heading, Skeleton , Button } from '@pancakeswap/uikit'
import { useTranslation } from 'contexts/Localization'
import useTheme from 'hooks/useTheme'
import PageSection from 'components/PageSection'
import dollarIcon from '../../Home/images/dollar.png'
import poundIcon from '../../Home/images/p.png'

import HistoryTabMenu from './HistoryTabMenu'

import {
    TITLE_BG,
    GET_TICKETS_BG,
    FINISHED_ROUNDS_BG,
    FINISHED_ROUNDS_BG_DARK,
    CHECK_PRIZES_BG,
  } from './pageSectionStyles'

export default function Finishround(){
    const { t } = useTranslation()
    const { isDark, theme } = useTheme()
    return(
        <>
            <section className="finish-section">
            <PageSection
                innerProps={{ style: { margin: '0', width: '100%' , paddingBottom: '250px' } }}
                background={isDark ? FINISHED_ROUNDS_BG_DARK : FINISHED_ROUNDS_BG}
                hasCurvedDivider={false}
                index={2}
            >
                <Flex width="100%" flexDirection="column" alignItems="center" justifyContent="center">
                <Heading mb="24px" scale="xl" className="pred-finish-title">
                    {t('Finished Rounds')}
                </Heading>
                <Box mb="24px">
                    <></>
                </Box>
                </Flex>
            </PageSection>
            </section>
        </>
    )
}